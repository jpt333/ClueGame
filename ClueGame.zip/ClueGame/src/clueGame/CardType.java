//Authors: Michael Berg and Jennifer Phan
package clueGame;

public enum CardType {
	PERSON, WEAPON, ROOM;
}
