//Authors: Michael Berg and Jennifer Phan
package clueGame;

public class Solution {
	public Card person;
	public Card room;
	public Card weapon;
	
	public Card getPerson() {
		return person;
	}
	public Card getRoom() {
		return room;
	}
	public Card getWeapon() {
		return weapon;
	}
	 public void setAnsPerson(Card personn) {
		 person = personn;
	 }
	 public void setAnsRoom(Card rooom) {
		 room = rooom;
	 }
	 public void setAnsWeapon(Card weaponn) {
		 weapon = weaponn;
	 }
	 
	
	
}
